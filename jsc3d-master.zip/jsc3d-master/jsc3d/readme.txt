JSC3D is an online 3D model viewer and toolkit based on HTML5 and Javascript. It is very handy for design sharing and product exhibition.

Supported File Formats:
- Wavefront obj
- STL (both binary and ascii)
- Autodesk 3DS
- OpenCTM Highly compressed mesh
